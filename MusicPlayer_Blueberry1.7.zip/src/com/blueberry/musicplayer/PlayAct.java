package com.blueberry.musicplayer;

import android.os.Bundle;
import android.provider.MediaStore;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

public class PlayAct extends Activity {

	// v1.4����
	TextView tv_playact_title;
	TextView tv_playact_artist;
	ImageView iv_playact_album;
	String[] receive_titles;
	String[] receive_artists;
	int[] _ids;
	int position;

	// v1.5����
	SeekBar playact_seekBar;
	TextView tv_playact_playedTime = null;
	TextView tv_playact_durationTime = null;
	int playact_duration;
	ImageButton btn_playact_power;
	int status;

	// v1.6���£���һ�ף���һ�װ�ť
	ImageButton btn_playact_next;
	ImageButton btn_playact_previous;
	public static final String NEXT_ACTION = "com.blueberry.NEXT_ACTION";
	public static final String PREVIOUS_ACTION = "com.blueberry.PREVIOUS_ACTION";
	public static final String UPDATE_PLAYACT_ACTION = "com.blueberry.UPDATE_PLAYACT_ACTION";
	PlayActReceiver playActReceiver;
	int playact_currentPosition;

	Intent intent;
	Bundle bundle;
	
	//v1.7����
	ImageButton btn_playact_playmode;
	public static final String PLAYMODE_ACTION = "com.blueberry.PLAYMODE_ACTION";

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);// ȫ����ʾ��һ��Ҫ��setContentViewǰ�棬����ᱨ�쳣
		setContentView(R.layout.play_act);

		intent = this.getIntent();
		bundle = intent.getExtras();

		// v1.4����:title,artist,album
		showInfo(bundle);
		showTime(bundle);
		tv_playact_playedTime = (TextView) findViewById(R.id.tv_playact_playedTime);
		showSeekBar(bundle);

		// v1.5���£����ſ��ؿ���
		showPlayActPower(bundle);

		// v1.6���£���һ�ף���һ�װ�ť
		showPreviousAndNextButton(bundle);
		
		//v1.7���£��Բ���ģʽ����		
		showPlayMode(bundle);		
		
		// ע�����
		playActReceiver = new PlayActReceiver();
		IntentFilter filter = new IntentFilter();
		filter.addAction(MainAct.CURRENT_ACTION);
		filter.addAction(MainAct.DURATION_ACTION);
		filter.addAction(MainAct.SEEKBAR_ACTION);
		filter.addAction(UPDATE_PLAYACT_ACTION);
		registerReceiver(playActReceiver, filter);
	}
	
	//v1.7�Բ���ģʽ����
	public void showPlayMode(Bundle bundle){
		btn_playact_playmode = (ImageButton) findViewById(R.id.btn_playact_playmode);
		MainAct.play_mode = bundle.getInt("play_mode");
		switch(MainAct.play_mode){
		case MainAct.SEQUENCE_PLAY:
			btn_playact_playmode.setImageResource(R.drawable.sequenct_play);
			break;
		case MainAct.RANDOM_PLAY:
			btn_playact_playmode.setImageResource(R.drawable.random_play);
			break;
		case MainAct.LIST_CYCLE:
			btn_playact_playmode.setImageResource(R.drawable.list_cycle);
			break;
		case MainAct.SINGLE_CYCLE:
			btn_playact_playmode.setImageResource(R.drawable.single_cycle);
			break;
		}				
		btn_playact_playmode.setOnClickListener(new OnClickListener() {				
			public void onClick(View v) {				
				switch(MainAct.play_mode){
				case MainAct.SEQUENCE_PLAY:
					btn_playact_playmode.setImageResource(R.drawable.random_play);
					MainAct.play_mode = MainAct.RANDOM_PLAY;
					Toast.makeText(PlayAct.this, "�������", Toast.LENGTH_SHORT).show();
					break;
				case MainAct.RANDOM_PLAY:
					btn_playact_playmode.setImageResource(R.drawable.list_cycle);
					MainAct.play_mode = MainAct.LIST_CYCLE;
					Toast.makeText(PlayAct.this, "�б�ѭ��", Toast.LENGTH_SHORT).show();
					break;
				case MainAct.LIST_CYCLE:
					btn_playact_playmode.setImageResource(R.drawable.single_cycle);
					MainAct.play_mode = MainAct.SINGLE_CYCLE;
					Toast.makeText(PlayAct.this, "����ѭ��", Toast.LENGTH_SHORT).show();
					break;
				case MainAct.SINGLE_CYCLE:
					btn_playact_playmode.setImageResource(R.drawable.sequenct_play);
					MainAct.play_mode = MainAct.SEQUENCE_PLAY;
					Toast.makeText(PlayAct.this, "˳�򲥷�", Toast.LENGTH_SHORT).show();
					break;
				}
				//���֮�󣬰��յ����mode���㲥
				Intent playmode_intent = new Intent();
				playmode_intent.setAction(PLAYMODE_ACTION);
				playmode_intent.putExtra("total", MainAct.total);
				playmode_intent.putExtra("play_mode", MainAct.play_mode);
				sendBroadcast(playmode_intent);
			}			
		});
		//Ĭ������°�˳�򲥷ŷ��㲥
		Intent playmode_intent = new Intent();
		playmode_intent.setAction(PLAYMODE_ACTION);
		playmode_intent.putExtra("total", MainAct.total);
		playmode_intent.putExtra("play_mode", MainAct.play_mode);
		sendBroadcast(playmode_intent);
		
	}
	
	// v1.6���£���������̷��ؼ��ļ���
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			// v1.6���£����ø�SelectActivity�Ľ���룬�����ý���֮���˻ص�Activity
			bundle.putInt("position", position);
			bundle.putInt("status", status);
			bundle.putInt("playact_duration", playact_duration);
			bundle.putInt("play_mode", MainAct.play_mode);
			intent.putExtras(bundle);
			this.setResult(0, intent);
			PlayAct.this.finish();
			return true;
		}
		return false;
	}

	public class PlayActReceiver extends BroadcastReceiver {
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();			
			// v1.6���£������һ�׻���һ�װ�ť�����²��Ž��档v1.7��һ�׸���������󣬸��½���
			if (action.equals(UPDATE_PLAYACT_ACTION)) {
				position = intent.getIntExtra("receive_position", -1);
				tv_playact_title.setText(receive_titles[position]);// ����title
				tv_playact_artist.setText(receive_artists[position]);// ����artist
				readArtwork(position);// ����album

				playact_duration = intent.getIntExtra("duration", -1);
				tv_playact_durationTime.setText(MainAct.toTime(playact_duration));// ������ʱ��
				playact_seekBar.setMax(playact_duration);// ���ý���������ʱ��
				btn_playact_power.setImageResource(R.drawable.pause);// ���¿��ƿ���
				//v1.7����
				MainAct.play_mode = intent.getIntExtra("receive_play_mode", -1);
				
				switch(MainAct.play_mode){
				case MainAct.SEQUENCE_PLAY:
					btn_playact_playmode.setImageResource(R.drawable.sequenct_play);
					break;
				case MainAct.RANDOM_PLAY:
					btn_playact_playmode.setImageResource(R.drawable.random_play);
					break;
				case MainAct.LIST_CYCLE:
					btn_playact_playmode.setImageResource(R.drawable.list_cycle);
					break;
				case MainAct.SINGLE_CYCLE:
					btn_playact_playmode.setImageResource(R.drawable.single_cycle);
					break;
				}
			}
			// v1.5:ʵʱ�����Ѳ���ʱ���Seekbar
			else if (action.equals(MainAct.CURRENT_ACTION)) {
				tv_playact_playedTime.setText(MainAct.toTime(MainAct.currentPosition));
				playact_seekBar.setProgress(MainAct.currentPosition);
			}
		}
	}

	// seekbar
	public void showSeekBar(Bundle bundle) {
		playact_seekBar = (SeekBar) findViewById(R.id.seekbar_playact);
		playact_seekBar.setMax(MainAct.duration);
		playact_seekBar
				.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
					public void onStopTrackingTouch(SeekBar seekBar) {
					}

					public void onStartTrackingTouch(SeekBar seekBar) {
					}

					public void onProgressChanged(SeekBar seekBar,
							int progress, boolean fromUser) {
						if (fromUser) {
							Intent seekbar_intent = new Intent();
							seekbar_intent.setAction(MainAct.SEEKBAR_ACTION);
							seekbar_intent.putExtra("progress", progress);
							sendBroadcast(seekbar_intent);
						}
					}
				});
	}

	// v1.5��������ʱ��
	public void showTime(Bundle bundle) {
		playact_duration = bundle.getInt("duration");
		tv_playact_durationTime = (TextView) findViewById(R.id.tv_playact_totalTime);
		tv_playact_durationTime.setText(MainAct.toTime(playact_duration));
	}

	// v1.6���£���һ�ף���һ�װ�ť
	public void showPreviousAndNextButton(Bundle bundle) {
		btn_playact_next = (ImageButton) findViewById(R.id.btn_playact_next);
		btn_playact_previous = (ImageButton) findViewById(R.id.btn_playact_previous);
		btn_playact_next.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent next_intent = new Intent();
				next_intent.setAction(NEXT_ACTION);
				next_intent.putExtra("_ids", _ids);
				next_intent.putExtra("play_mode",MainAct.play_mode);
				position = position + 1;
				if(position == MainAct.total)
					position = 0;
				next_intent.putExtra("position", position);
				sendBroadcast(next_intent);
			}
		});
		btn_playact_previous.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent previous_intent = new Intent();
				previous_intent.setAction(PREVIOUS_ACTION);
				previous_intent.putExtra("_ids", _ids);
				previous_intent.putExtra("play_mode",MainAct.play_mode);
				position = position - 1;
				if(position <0)
					position = MainAct.total -1;
				previous_intent.putExtra("position", position);
				sendBroadcast(previous_intent);
			}
		});
	}

	// v1.5���£��Բ��ſ��ؼ���
	public void showPlayActPower(final Bundle bundle) {
		btn_playact_power = (ImageButton) findViewById(R.id.btn_playact_power);
		status = bundle.getInt("status");
		switch (status) {
		case 1:
			btn_playact_power.setImageResource(R.drawable.pause);
			break;
		case 2:
			btn_playact_power.setImageResource(R.drawable.pause);
			break;
		case 3:
			btn_playact_power.setImageResource(R.drawable.play);
			break;
		}
		btn_playact_power.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				switch (status) {
				case 1:
					btn_playact_power.setImageResource(R.drawable.pause);
					Intent unplay_intent = new Intent();
					unplay_intent.setAction(MainAct.MAINACTUNPLAY_ACTION);
					sendBroadcast(unplay_intent);
					break;
				case 2:
					btn_playact_power.setImageResource(R.drawable.play);
					Intent play_intent = new Intent();
					play_intent.setAction(MainAct.MAINACTPLAY_ACTION);
					status = 3;// �����ֹ�ָ��status,��Ϊstatusֻ�ڵ�һ�δ�������ʱ������ֵ
					sendBroadcast(play_intent);
					break;
				case 3:
					btn_playact_power.setImageResource(R.drawable.pause);
					Intent pause_intent = new Intent();
					pause_intent.setAction(MainAct.MAINACTPAUSE_ACTION);
					status = 2;
					sendBroadcast(pause_intent);
					break;
				}
			}
		});
	}

	// v1.4���£���ʾtitle,artist,album����
	public void showInfo(Bundle bundle) {

		tv_playact_title = (TextView) findViewById(R.id.tv_playact_title);
		tv_playact_artist = (TextView) findViewById(R.id.tv_playact_artist);
		iv_playact_album = (ImageView) findViewById(R.id.iv_playact_album);

		position = bundle.getInt("position");
		_ids = bundle.getIntArray("_ids");
		receive_titles = bundle.getStringArray("receive_titles");
		receive_artists = bundle.getStringArray("receive_artists");
		tv_playact_title.setText(receive_titles[position]);
		tv_playact_artist.setText(receive_artists[position]);
		readArtwork(position);
	}

	// v1.4���£���ȡר��ͼƬ
	public void readArtwork(int position) {
		// ��ѯ��positionλ�õĸ�����Ϣ
		Cursor cursor = getContentResolver().query(
				MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
				new String[] { MediaStore.Audio.Media.TITLE,
						MediaStore.Audio.Media.DURATION,
						MediaStore.Audio.Media.ARTIST,
						MediaStore.Audio.Media.ALBUM,
						MediaStore.Audio.Media.DISPLAY_NAME,
						MediaStore.Audio.Media.ALBUM_ID }, "_id=?",
				new String[] { _ids[position] + "" }, null);
		cursor.moveToFirst();// �α��Ƶ���һλ
		// ��ȡר��ͼƬ
		Bitmap bitMap = LoadImage.getArtwork(this, cursor.getInt(cursor
				.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)));
		iv_playact_album.setImageBitmap(bitMap);
	}
}
